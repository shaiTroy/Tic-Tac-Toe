#!/bin/bash
source /Users/shaitroy/d/Tic-Tac-Toe/venv/bin/activate
exec python /Users/shaitroy/d/Tic-Tac-Toe/TicTacToe.app/Contents/MacOS/ticTacToe.py
